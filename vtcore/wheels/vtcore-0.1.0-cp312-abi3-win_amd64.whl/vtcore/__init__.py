from .vtcore import *

__doc__ = vtcore.__doc__
if hasattr(vtcore, "__all__"):
    __all__ = vtcore.__all__